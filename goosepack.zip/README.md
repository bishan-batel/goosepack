# Southbrit Goose Pack

Minecraft unobtrusive texture pack that adds little easter-eggs, quality of life features, and some decorational aspects to games made by <b>bishan\_, RabbidFlea, BlueXander</b> and other friends (on Vibrant Community Server)

## Credits for 3rd party animations / models used

- "Jack o'lantern" by YanMaojie
  Available for download at https://blockmodels.com/model/543/
- "Biplane" by Zenith
  Available for download at https://blockmodels.com/model/553/
- "M82" by 02h30
  Available for download at https://blockmodels.com/model/679/
- "Inosukes Sword (Demon Slayer)" by Gengar
  Available for download at https://blockmodels.com/model/606/